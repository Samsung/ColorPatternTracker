var struct_j_n_i_c_l_tracker_1_1_c_l_tracker_1_1_g_p_u_vars =
[
    [ "context", "struct_j_n_i_c_l_tracker_1_1_c_l_tracker_1_1_g_p_u_vars.html#a1e9bdc307d87ca7b490bd77efdaad32e", null ],
    [ "queue", "struct_j_n_i_c_l_tracker_1_1_c_l_tracker_1_1_g_p_u_vars.html#a78ec122920348b2262779e67458d8e7c", null ]
];