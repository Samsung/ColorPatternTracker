var dir_a5d2264ba86f994c8c03181d81074211 =
[
    [ "opencl", "dir_b48e3d63d0ae6c97489a09257e4e52fe.html", "dir_b48e3d63d0ae6c97489a09257e4e52fe" ],
    [ "CLManager.cpp", "_c_l_manager_8cpp.html", null ],
    [ "CLManager.h", "_c_l_manager_8h.html", "_c_l_manager_8h" ],
    [ "CLTracker.cpp", "_c_l_tracker_8cpp.html", null ],
    [ "CLTracker.h", "_c_l_tracker_8h.html", [
      [ "CLTracker", "class_j_n_i_c_l_tracker_1_1_c_l_tracker.html", "class_j_n_i_c_l_tracker_1_1_c_l_tracker" ],
      [ "int2", "struct_j_n_i_c_l_tracker_1_1_c_l_tracker_1_1int2.html", "struct_j_n_i_c_l_tracker_1_1_c_l_tracker_1_1int2" ],
      [ "GPUVars", "struct_j_n_i_c_l_tracker_1_1_c_l_tracker_1_1_g_p_u_vars.html", "struct_j_n_i_c_l_tracker_1_1_c_l_tracker_1_1_g_p_u_vars" ],
      [ "CornerRefinementParam", "struct_j_n_i_c_l_tracker_1_1_c_l_tracker_1_1_corner_refinement_param.html", "struct_j_n_i_c_l_tracker_1_1_c_l_tracker_1_1_corner_refinement_param" ]
    ] ],
    [ "util.cpp", "util_8cpp.html", "util_8cpp" ],
    [ "util.h", "util_8h.html", "util_8h" ]
];