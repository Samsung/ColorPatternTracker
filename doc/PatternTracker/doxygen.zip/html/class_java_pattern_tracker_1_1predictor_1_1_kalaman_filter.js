var class_java_pattern_tracker_1_1predictor_1_1_kalaman_filter =
[
    [ "KalamanFilter", "class_java_pattern_tracker_1_1predictor_1_1_kalaman_filter.html#ab3fa91e1039fb32944c86397d49cc5d9", null ],
    [ "initializeKalmanJava", "class_java_pattern_tracker_1_1predictor_1_1_kalaman_filter.html#a0d74f8dd3959494d686bd0f26c8c6d9c", null ],
    [ "updateKalmanJava", "class_java_pattern_tracker_1_1predictor_1_1_kalaman_filter.html#a95b729fb5c127fbcb7e764bb3377d7d6", null ],
    [ "kalman_m_n1", "class_java_pattern_tracker_1_1predictor_1_1_kalaman_filter.html#a23bc5a2d432e58728fc8d5d028346ad9", null ]
];