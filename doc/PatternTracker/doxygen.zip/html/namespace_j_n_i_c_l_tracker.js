var namespace_j_n_i_c_l_tracker =
[
    [ "CLManager", "class_j_n_i_c_l_tracker_1_1_c_l_manager.html", "class_j_n_i_c_l_tracker_1_1_c_l_manager" ],
    [ "CLTracker", "class_j_n_i_c_l_tracker_1_1_c_l_tracker.html", "class_j_n_i_c_l_tracker_1_1_c_l_tracker" ]
];