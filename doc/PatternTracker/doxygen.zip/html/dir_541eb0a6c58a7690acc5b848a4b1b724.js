var dir_541eb0a6c58a7690acc5b848a4b1b724 =
[
    [ "samsung", "dir_f8e963efb0f5691582bc026130bc32c0.html", "dir_f8e963efb0f5691582bc026130bc32c0" ]
];