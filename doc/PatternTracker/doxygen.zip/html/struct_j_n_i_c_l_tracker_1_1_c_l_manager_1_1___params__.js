var struct_j_n_i_c_l_tracker_1_1_c_l_manager_1_1___params__ =
[
    [ "_Params_", "struct_j_n_i_c_l_tracker_1_1_c_l_manager_1_1___params__.html#a9cf2a0298f9d1728c92d2d8689fc9bf6", null ],
    [ "deviceIndex", "struct_j_n_i_c_l_tracker_1_1_c_l_manager_1_1___params__.html#a7b8dbbaca1ba5fd339bcc616d7702cd2", null ],
    [ "opengl", "struct_j_n_i_c_l_tracker_1_1_c_l_manager_1_1___params__.html#aaaffccda772d370a592e634395b45762", null ],
    [ "platformIndex", "struct_j_n_i_c_l_tracker_1_1_c_l_manager_1_1___params__.html#a6d9b77f7902b317364c70899fbeacf16", null ],
    [ "type", "struct_j_n_i_c_l_tracker_1_1_c_l_manager_1_1___params__.html#a6c340fbeac6051f38282dd747b4b74d7", null ],
    [ "verify", "struct_j_n_i_c_l_tracker_1_1_c_l_manager_1_1___params__.html#ace37e007e206e44c3407049e50075592", null ]
];