var class_j_n_i_c_l_tracker_1_1_c_l_manager =
[
    [ "_Params_", "struct_j_n_i_c_l_tracker_1_1_c_l_manager_1_1___params__.html", "struct_j_n_i_c_l_tracker_1_1_c_l_manager_1_1___params__" ],
    [ "Params", "class_j_n_i_c_l_tracker_1_1_c_l_manager.html#af64630299b1f42960b5e7c29a28da7ef", null ],
    [ "CLManager", "class_j_n_i_c_l_tracker_1_1_c_l_manager.html#ad3e7644b62dbafde7aa02b4ece580a3a", null ],
    [ "~CLManager", "class_j_n_i_c_l_tracker_1_1_c_l_manager.html#a1d986625221fa4790b2a4a3773d2cad1", null ],
    [ "initCL", "class_j_n_i_c_l_tracker_1_1_c_l_manager.html#a6e67e2ba6830731687bec4cc8b77f81a", null ],
    [ "releaseCL", "class_j_n_i_c_l_tracker_1_1_c_l_manager.html#a4207db265fe95f36837e2c65046d12c1", null ],
    [ "m_clContext", "class_j_n_i_c_l_tracker_1_1_c_l_manager.html#a50b943308685c5735c451814369bc52a", null ],
    [ "m_device", "class_j_n_i_c_l_tracker_1_1_c_l_manager.html#aff8c3e55f62a11dc2009a05b9c904ad4", null ],
    [ "m_program", "class_j_n_i_c_l_tracker_1_1_c_l_manager.html#a0414301d75825c5dc6d906c981d88b3a", null ],
    [ "m_queue", "class_j_n_i_c_l_tracker_1_1_c_l_manager.html#ac9d6a52d1b4a0bdb45750f0b67ef12aa", null ],
    [ "max_cu", "class_j_n_i_c_l_tracker_1_1_c_l_manager.html#a169511cdaa35013c913d2002d250c6e7", null ],
    [ "params", "class_j_n_i_c_l_tracker_1_1_c_l_manager.html#a87a347d041c9ea4cfef01d9111ddd9b8", null ]
];