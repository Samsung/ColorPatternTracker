var struct_j_n_i_c_l_tracker_1_1_c_l_tracker_1_1_corner_refinement_param =
[
    [ "colVals", "struct_j_n_i_c_l_tracker_1_1_c_l_tracker_1_1_corner_refinement_param.html#a97a09b479a17e8f944c9fc3fd19853e1", null ],
    [ "crossIDs", "struct_j_n_i_c_l_tracker_1_1_c_l_tracker_1_1_corner_refinement_param.html#afac3c7245457f09482bc66b39af19a4b", null ],
    [ "crossPts", "struct_j_n_i_c_l_tracker_1_1_c_l_tracker_1_1_corner_refinement_param.html#ae79a573683d6d449ba68e077d3fd489a", null ],
    [ "mem_16Pts", "struct_j_n_i_c_l_tracker_1_1_c_l_tracker_1_1_corner_refinement_param.html#ad57e0d17a5f09e4a44ead6ed31e982b8", null ],
    [ "mem_col16Pts", "struct_j_n_i_c_l_tracker_1_1_c_l_tracker_1_1_corner_refinement_param.html#a6032a302706115e0c0fd99da08b917e0", null ],
    [ "mem_crossIds", "struct_j_n_i_c_l_tracker_1_1_c_l_tracker_1_1_corner_refinement_param.html#ad008c21bdb10d616902ce86305cb0b06", null ],
    [ "mem_crossPts", "struct_j_n_i_c_l_tracker_1_1_c_l_tracker_1_1_corner_refinement_param.html#a657094ed14b2c2d7914042e6baf956af", null ],
    [ "mLocRecFromCornerData", "struct_j_n_i_c_l_tracker_1_1_c_l_tracker_1_1_corner_refinement_param.html#a223eb582a2e2624b04a39562d7e1083d", null ],
    [ "ptsTM", "struct_j_n_i_c_l_tracker_1_1_c_l_tracker_1_1_corner_refinement_param.html#ac005541ae5069e6d4b630771df02c48c", null ],
    [ "ptsTM_homo", "struct_j_n_i_c_l_tracker_1_1_c_l_tracker_1_1_corner_refinement_param.html#ad2a7df8099bffc9121abbe4f024fcea5", null ]
];