var _c_l_manager_8h =
[
    [ "CLManager", "class_j_n_i_c_l_tracker_1_1_c_l_manager.html", "class_j_n_i_c_l_tracker_1_1_c_l_manager" ],
    [ "_Params_", "struct_j_n_i_c_l_tracker_1_1_c_l_manager_1_1___params__.html", "struct_j_n_i_c_l_tracker_1_1_c_l_manager_1_1___params__" ],
    [ "CHECK_ERROR_OCL", "_c_l_manager_8h.html#aa6cd6a2e41bd16a4e10e33a0f46c7ebf", null ]
];