var namespace_java_pattern_tracker_1_1predictor =
[
    [ "KalamanFilter", "class_java_pattern_tracker_1_1predictor_1_1_kalaman_filter.html", "class_java_pattern_tracker_1_1predictor_1_1_kalaman_filter" ],
    [ "LinearPrediction", "class_java_pattern_tracker_1_1predictor_1_1_linear_prediction.html", "class_java_pattern_tracker_1_1predictor_1_1_linear_prediction" ]
];