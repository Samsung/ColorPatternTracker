var class_java_pattern_tracker_1_1_custom_g_l_surface_view =
[
    [ "CustomGLSurfaceView", "class_java_pattern_tracker_1_1_custom_g_l_surface_view.html#a502162da3c435fd3528b36a6c029af59", null ],
    [ "setDisplayDim", "class_java_pattern_tracker_1_1_custom_g_l_surface_view.html#a081b2b33d7ad704e3ae6d1780cb8a64c", null ],
    [ "surfaceChanged", "class_java_pattern_tracker_1_1_custom_g_l_surface_view.html#a51b5e90337e9fad40e26e32c12c20173", null ],
    [ "surfaceCreated", "class_java_pattern_tracker_1_1_custom_g_l_surface_view.html#a11dc40ba64adbb9268b648ea48f94607", null ],
    [ "surfaceDestroyed", "class_java_pattern_tracker_1_1_custom_g_l_surface_view.html#afb4d87cc2ac20858595c2c97464ab147", null ],
    [ "mRenderer", "class_java_pattern_tracker_1_1_custom_g_l_surface_view.html#ae17a71c3284bbe0b296b4ffe86048935", null ]
];