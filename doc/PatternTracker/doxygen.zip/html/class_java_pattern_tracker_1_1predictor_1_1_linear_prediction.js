var class_java_pattern_tracker_1_1predictor_1_1_linear_prediction =
[
    [ "LinearPrediction", "class_java_pattern_tracker_1_1predictor_1_1_linear_prediction.html#af03fd70c595324271a4f5f198ab8d0bd", null ],
    [ "clear", "class_java_pattern_tracker_1_1predictor_1_1_linear_prediction.html#a282dc0a066ba4f6853d406041eb299eb", null ],
    [ "Estimate", "class_java_pattern_tracker_1_1predictor_1_1_linear_prediction.html#a646379bbc4c570439002ef58ce44e1ac", null ],
    [ "estimateImageCornersVel", "class_java_pattern_tracker_1_1predictor_1_1_linear_prediction.html#adef1d40696584f19e50e6b8fd5fe632d", null ],
    [ "predictImageCorners", "class_java_pattern_tracker_1_1predictor_1_1_linear_prediction.html#a8cb4f2b448da0c30571d627c123e6d43", null ],
    [ "updatePrevCorners", "class_java_pattern_tracker_1_1predictor_1_1_linear_prediction.html#aaff9dc79e08526e2bb6f7819b6bbaa20", null ],
    [ "mPrevCorners", "class_java_pattern_tracker_1_1predictor_1_1_linear_prediction.html#a2b84a89288bd10808c44a521ac1f7a2a", null ],
    [ "mPrevCornersAvailable", "class_java_pattern_tracker_1_1predictor_1_1_linear_prediction.html#a34dfaaa96cc968d71cbbe0728f955364", null ]
];