var dir_537656809e61c5d487a5620fbd980780 =
[
    [ "KalamanFilter.java", "_kalaman_filter_8java.html", [
      [ "KalamanFilter", "class_java_pattern_tracker_1_1predictor_1_1_kalaman_filter.html", "class_java_pattern_tracker_1_1predictor_1_1_kalaman_filter" ]
    ] ],
    [ "LinearPrediction.java", "_linear_prediction_8java.html", [
      [ "LinearPrediction", "class_java_pattern_tracker_1_1predictor_1_1_linear_prediction.html", "class_java_pattern_tracker_1_1predictor_1_1_linear_prediction" ]
    ] ]
];