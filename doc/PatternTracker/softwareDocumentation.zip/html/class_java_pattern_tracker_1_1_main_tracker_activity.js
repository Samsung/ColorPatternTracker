var class_java_pattern_tracker_1_1_main_tracker_activity =
[
    [ "onCreate", "class_java_pattern_tracker_1_1_main_tracker_activity.html#a5e4ad425c57bc47118e674ffb07b10f5", null ],
    [ "onDestroy", "class_java_pattern_tracker_1_1_main_tracker_activity.html#aa554b4a2971ee7810fa984ba0fd352a4", null ],
    [ "onPause", "class_java_pattern_tracker_1_1_main_tracker_activity.html#a81eb50cf3ba3f9282f0e4419b2995f14", null ],
    [ "onResume", "class_java_pattern_tracker_1_1_main_tracker_activity.html#a6163833153df57e9505cbf8248e9cf5a", null ],
    [ "setDebugButton", "class_java_pattern_tracker_1_1_main_tracker_activity.html#a14e5a52934af4c27283a45efcdddd514", null ],
    [ "setUpdateGeometryButton", "class_java_pattern_tracker_1_1_main_tracker_activity.html#ae076f038405da2e0e8aa71b55199d041", null ],
    [ "updateText", "class_java_pattern_tracker_1_1_main_tracker_activity.html#a27b8235a06eb9927f3bebcfb55801ea7", null ],
    [ "mView", "class_java_pattern_tracker_1_1_main_tracker_activity.html#ad90058b92eceffa7e84cc470d6329f32", null ],
    [ "mWL", "class_java_pattern_tracker_1_1_main_tracker_activity.html#a82b17fd266ba6d2bbd3d2d63e734fcaf", null ]
];