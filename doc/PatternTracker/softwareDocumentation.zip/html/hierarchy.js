var hierarchy =
[
    [ "JNICLTracker::CLManager::_Params_", "struct_j_n_i_c_l_tracker_1_1_c_l_manager_1_1___params__.html", null ],
    [ "JavaPatternTracker.stereo.Algo3D", "class_java_pattern_tracker_1_1stereo_1_1_algo3_d.html", null ],
    [ "JavaPatternTracker.stereo.CameraModelParams", "class_java_pattern_tracker_1_1stereo_1_1_camera_model_params.html", null ],
    [ "JNICLTracker::CLManager", "class_j_n_i_c_l_tracker_1_1_c_l_manager.html", null ],
    [ "JNICLTracker::CLTracker", "class_j_n_i_c_l_tracker_1_1_c_l_tracker.html", null ],
    [ "JavaPatternTracker.ColorGridTracker", "class_java_pattern_tracker_1_1_color_grid_tracker.html", null ],
    [ "Comparable", null, [
      [ "JavaPatternTracker.ColorGridTracker.Paird", "class_java_pattern_tracker_1_1_color_grid_tracker_1_1_paird.html", null ]
    ] ],
    [ "JNICLTracker::CLTracker::CornerRefinementParam", "struct_j_n_i_c_l_tracker_1_1_c_l_tracker_1_1_corner_refinement_param.html", null ],
    [ "JNICLTracker::CLTracker::GPUVars", "struct_j_n_i_c_l_tracker_1_1_c_l_tracker_1_1_g_p_u_vars.html", null ],
    [ "JNICLTracker::CLTracker::int2", "struct_j_n_i_c_l_tracker_1_1_c_l_tracker_1_1int2.html", null ],
    [ "JavaPatternTracker.util.IOUtil", "class_java_pattern_tracker_1_1util_1_1_i_o_util.html", null ],
    [ "JavaPatternTracker.predictor.KalamanFilter", "class_java_pattern_tracker_1_1predictor_1_1_kalaman_filter.html", null ],
    [ "JavaPatternTracker.predictor.LinearPrediction", "class_java_pattern_tracker_1_1predictor_1_1_linear_prediction.html", null ],
    [ "Renderer", null, [
      [ "JavaPatternTracker.CustomGLRenderer", "class_java_pattern_tracker_1_1_custom_g_l_renderer.html", null ]
    ] ],
    [ "JavaPatternTracker.util.TUtil", "class_java_pattern_tracker_1_1util_1_1_t_util.html", null ],
    [ "Activity", null, [
      [ "JavaPatternTracker.MainTrackerActivity", "class_java_pattern_tracker_1_1_main_tracker_activity.html", null ]
    ] ],
    [ "GLSurfaceView", null, [
      [ "JavaPatternTracker.CustomGLSurfaceView", "class_java_pattern_tracker_1_1_custom_g_l_surface_view.html", null ]
    ] ],
    [ "Handler", null, [
      [ "JavaPatternTracker.util.HandlerExtension", "class_java_pattern_tracker_1_1util_1_1_handler_extension.html", null ]
    ] ]
];