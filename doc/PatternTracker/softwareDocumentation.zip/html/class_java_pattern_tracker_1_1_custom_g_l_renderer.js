var class_java_pattern_tracker_1_1_custom_g_l_renderer =
[
    [ "captureFrame", "class_java_pattern_tracker_1_1_custom_g_l_renderer.html#ae74273a9b4f4dd7da857a393d5cbe694", null ],
    [ "close", "class_java_pattern_tracker_1_1_custom_g_l_renderer.html#a29fe8a8d60a89c5aa885bd4de3a511f3", null ],
    [ "frameIdForTracker", "class_java_pattern_tracker_1_1_custom_g_l_renderer.html#abb649074144903e5b8b9738d6cf739f9", null ],
    [ "initBT", "class_java_pattern_tracker_1_1_custom_g_l_renderer.html#af7222b67aba0c9178a74ff6c847eb49c", null ],
    [ "measureFPS", "class_java_pattern_tracker_1_1_custom_g_l_renderer.html#ad3501b435d589b6e35893fdacbedb85f", null ],
    [ "onDestroy", "class_java_pattern_tracker_1_1_custom_g_l_renderer.html#aa84401836cd1e2d19b3b2718fc563b26", null ],
    [ "onDrawFrame", "class_java_pattern_tracker_1_1_custom_g_l_renderer.html#a2107a8fcd67447772197a01c6ff80ccf", null ],
    [ "onSurfaceChanged", "class_java_pattern_tracker_1_1_custom_g_l_renderer.html#ac739e67ac3ad54e60d8a35541609705a", null ],
    [ "onSurfaceCreated", "class_java_pattern_tracker_1_1_custom_g_l_renderer.html#a8ee04204b84f348a8fd78baf12446952", null ],
    [ "setDisplayDim", "class_java_pattern_tracker_1_1_custom_g_l_renderer.html#a2d35f701d9ea536beb14555cf224a9d6", null ],
    [ "camera_res", "class_java_pattern_tracker_1_1_custom_g_l_renderer.html#ae4792baaeb27379f5d7bbe491fd82bce", null ],
    [ "data_sent", "class_java_pattern_tracker_1_1_custom_g_l_renderer.html#a8ba7b1fa1ce8789722d5c59803a18d98", null ],
    [ "display_dim", "class_java_pattern_tracker_1_1_custom_g_l_renderer.html#a984b1faf1ce64abb848cae721a2c2853", null ],
    [ "frames", "class_java_pattern_tracker_1_1_custom_g_l_renderer.html#a72974a9fa659dcdd7ecb550166b48976", null ],
    [ "lastFPScomputeTime", "class_java_pattern_tracker_1_1_custom_g_l_renderer.html#a87d17becd80f0832b0bbc53bdc9a1543", null ],
    [ "mCgTrack", "class_java_pattern_tracker_1_1_custom_g_l_renderer.html#ae9f17022ecdce7cbf162b81c42c2a809", null ],
    [ "mPositionComm", "class_java_pattern_tracker_1_1_custom_g_l_renderer.html#a7eb1c89ccfee18c3e4be2e4a9c5218d8", null ],
    [ "mSTexture", "class_java_pattern_tracker_1_1_custom_g_l_renderer.html#a781e2169281f3d15dab7c81d422e2dc4", null ],
    [ "processedCaptureTime", "class_java_pattern_tracker_1_1_custom_g_l_renderer.html#a98a61c8804f11b60c6e69231f19c1d53", null ],
    [ "sendBT", "class_java_pattern_tracker_1_1_custom_g_l_renderer.html#a2d1c13dc249dcc8eb77aa099d0fe1be5", null ],
    [ "TAG", "class_java_pattern_tracker_1_1_custom_g_l_renderer.html#a0f421b99a78842a09eb8b3b6a4f45de1", null ]
];