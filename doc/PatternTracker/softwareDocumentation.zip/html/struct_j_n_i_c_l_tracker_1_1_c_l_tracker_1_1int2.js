var struct_j_n_i_c_l_tracker_1_1_c_l_tracker_1_1int2 =
[
    [ "x", "struct_j_n_i_c_l_tracker_1_1_c_l_tracker_1_1int2.html#a7bb027ad392490259c830157bebadf99", null ],
    [ "y", "struct_j_n_i_c_l_tracker_1_1_c_l_tracker_1_1int2.html#a602896d96bde7c130562851d3140014a", null ]
];