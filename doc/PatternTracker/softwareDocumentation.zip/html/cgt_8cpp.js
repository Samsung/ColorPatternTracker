var cgt_8cpp =
[
    [ "Java_JavaPatternTracker_ColorGridTracker_destroyCL", "cgt_8cpp.html#a0254ac70f2e2ac5e0625b03e2a669b76", null ],
    [ "Java_JavaPatternTracker_ColorGridTracker_initCL", "cgt_8cpp.html#a20bee0b08976a5b71c94dc26433c3642", null ],
    [ "Java_JavaPatternTracker_ColorGridTracker_processFrame", "cgt_8cpp.html#a2103c2086cd060454f7b3f4d3b155d8c", null ]
];