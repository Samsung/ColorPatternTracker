var dir_0fcb29df49a57305abbc48ff0116a641 =
[
    [ "Algo3D.java", "_algo3_d_8java.html", [
      [ "Algo3D", "class_java_pattern_tracker_1_1stereo_1_1_algo3_d.html", "class_java_pattern_tracker_1_1stereo_1_1_algo3_d" ]
    ] ],
    [ "CameraModelParams.java", "_camera_model_params_8java.html", [
      [ "CameraModelParams", "class_java_pattern_tracker_1_1stereo_1_1_camera_model_params.html", "class_java_pattern_tracker_1_1stereo_1_1_camera_model_params" ]
    ] ]
];