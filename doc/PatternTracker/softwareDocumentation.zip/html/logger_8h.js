var logger_8h =
[
    [ "LOG_DEBUG", "logger_8h.html#a754b3d074e0af4ad3c7b918dd77ecb2d", null ],
    [ "LOG_ERROR", "logger_8h.html#ad4a9117ce894e3319e903142347a0f63", null ],
    [ "LOG_INFO", "logger_8h.html#a378e28bfcb78d17285210d6bbb70a083", null ]
];